#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <filesystem>
#include <iomanip>
#include <algorithm>

#ifdef _WIN32
#include <windows.h>
#endif

namespace fs = std::filesystem;

#define RESET   "\033[0m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"
#define GREEN   "\033[32m"

struct Student {
    std::string id;
    std::string name;
    int score = -1; 
    std::string duration = "--:--:--";
};

std::string clean(std::string s) {
    std::string result;
    for (char c : s) {
        if (c != '\"' && c != ',' && c != '}' && c != ']' && c != '{') {
            result += c;
        }
    }
    size_t first = result.find_first_not_of(" \t\n\r");
    if (std::string::npos == first) return "";
    size_t last = result.find_last_not_of(" \t\n\r");
    return result.substr(first, (last - first + 1));
}

std::string getVal(const std::string& json, const std::string& key) {
    std::string k = "\"" + key + "\"";
    size_t p = json.find(k);
    if (p == std::string::npos) return "";
    size_t colon = json.find(':', p + k.length());
    if (colon == std::string::npos) return "";
    size_t start = colon + 1;
    size_t end = json.find_first_of(",}", start);
    if (end == std::string::npos) end = json.length();
    return json.substr(start, end - start);
}

int main() {
    #ifdef _WIN32
        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        if (hOut != INVALID_HANDLE_VALUE) {
            DWORD dwMode = 0;
            if (GetConsoleMode(hOut, &dwMode)) {
                dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
                SetConsoleMode(hOut, dwMode);
            }
        }
    #endif

    std::vector<std::string> order;
    std::map<std::string, Student> registry;

    std::ifstream listFile("list.json");
    if (!listFile.is_open()) {
        std::cerr << "[ERROR] could not open list.json" << std::endl;
        return 1;
    }

    std::string line;
    while (std::getline(listFile, line)) {
        size_t colonPos = line.find(':');
        if (colonPos != std::string::npos) {
            std::string id = clean(line.substr(0, colonPos));
            std::string name = clean(line.substr(colonPos + 1));
            if (!id.empty()) {
                order.push_back(id);
                registry[id].id = id;
                registry[id].name = name;
            }
        }
    }

    if (!fs::exists("student_submissions")) {
        std::cerr << "[ERROR] Directory 'student_submissions' not found!" << std::endl;
        return 1;
    }

    for (const auto& entry : fs::directory_iterator("student_submissions")) {
        if (entry.path().extension() == ".json") {
            std::string id = entry.path().stem().string();
            if (registry.count(id)) {
                std::ifstream f(entry.path());
                std::string c((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
                
                std::string rawScore = getVal(c, "score");
                if (!rawScore.empty()) {
                    registry[id].score = std::stoi(clean(rawScore));
                    // getVal already finds the value, clean now preserves the colons
                    std::string dur = clean(getVal(c, "timeTaken"));
                    if (!dur.empty() && dur != "null") registry[id].duration = dur;
                }
            }
        }
    }

    std::ofstream out("results.txt");
    int maxScore = -1, minScore = 100;
    int totalProcessed = 0;

    std::cout << "[SYSTEM] Starting Checking Processes..." << std::endl;
    std::cout << "-----------------------------------------------" << std::endl;
    out << "----------------------------------------------------------------------" << std::endl;
    out << std::left << std::setw(15) << "STUDENT ID" << std::setw(25) << "NAME" << std::setw(15) << "SCORE" << "DURATION" << std::endl;
    out << "----------------------------------------------------------------------" << std::endl;

    for (const auto& id : order) {
        if (registry[id].score == -1) continue; 
        Student& s = registry[id];

        if (s.score > maxScore) maxScore = s.score;
        if (s.score < minScore) minScore = s.score;

        std::cout << "[LOG] Processing: " << s.id << " (" << s.name << ")" << std::endl;

        std::string color = (s.score <= 5) ? RED : (s.score >= 16) ? GREEN : YELLOW;
        out << std::left << std::setw(15) << s.id << std::setw(25) << s.name 
            << color << std::left << std::setw(15) << (std::to_string(s.score) + "/20") << RESET
            << s.duration << std::endl;
        totalProcessed++;
    }

    std::string highestList = "", lowestList = "";
    for (const auto& id : order) {
        if (registry[id].score == -1) continue;
        Student& s = registry[id];
        std::string entry = s.id + " (" + s.name + ")";
        if (s.score == maxScore) highestList += (highestList.empty() ? "" : ", ") + entry;
        if (s.score == minScore) lowestList += (lowestList.empty() ? "" : ", ") + entry;
    }

    out << "----------------------------------------------------------------------" << std::endl;
    out << "HIGHEST MARKS (" << maxScore << "/20): " << highestList << std::endl;
    out << "LOWEST MARKS (" << minScore << "/20): " << lowestList << std::endl;
    out << "----------------------------------------------------------------------" << std::endl;

    std::cout << "-----------------------------------------------" << std::endl;
    std::cout << "[SUCCESS] Processed " << totalProcessed << " student files." << std::endl;
    
    return 0;
}