const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(__dirname));

const questionsData = JSON.parse(fs.readFileSync('./questions.json', 'utf8'));
const allowedUsers = { "AUSWD2900": "pass1", "AUSWD3000": "pass2", "AUSWD3900": "pass3", "AUSWD4000": "pass4" };

app.get('/get-questions', (req, res) => {
    const safeQuestions = questionsData.map(({correct, ...rest}) => rest);
    res.json(safeQuestions);
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (allowedUsers[username] === password) res.sendStatus(200);
    else res.sendStatus(401);
});

app.post('/submit-exam', (req, res) => {
    const { username, answers, timeTaken } = req.body;
    const now = new Date();
    const subClock = now.toTimeString().split(' ')[0];

    let score = 0;
    questionsData.forEach(q => {
        if (answers[q.id] === q.correct) score++;
    });

    const result = { username, score, timeTaken, submissionClock: subClock, answers };
    if (!fs.existsSync('./student_submissions')) fs.mkdirSync('./student_submissions');
    fs.writeFileSync(`./student_submissions/${username}.json`, JSON.stringify(result, null, 2));
    
    console.log(`[${subClock}] Submission: ${username} | Duration: ${timeTaken}`);
    res.status(200).send("Success");
});

app.listen(3000, () => console.log("AUS Exam Server Live: http://localhost:3000"));