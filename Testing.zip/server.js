const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(__dirname));

const questionsData = JSON.parse(fs.readFileSync('./questions.json', 'utf8'));
const allowedUsers = { 
    "AUSWD2000": "pass1", 
    "AUSWD2100": "pass2", 
    "AUSWD2200": "pass3", 
    "AUSWD2300": "pass4", 
    "AUSWD2400": "pass5", 
    "AUSWD2500": "pass6", 
    "AUSWD2600": "pass7", 
    "AUSWD2700": "pass8", 
    "AUSWD2800": "pass9", 
    "AUSWD2900": "pass10", 
    "AUSWD3000": "pass11", 
    "AUSWD3100": "pass12", 
    "AUSWD3200": "pass13", 
    "AUSWD3300": "pass14", 
    "AUSWD3400": "pass15",
    "AUSWD3500": "pass16",
    "AUSWD3600": "pass17",
    "AUSWD3700": "pass18",
    "AUSWD3800": "pass19",
    "AUSWD3800": "pass20",
    "AUSWD3900": "pass21",
    "AUSWD4000": "pass22",
    "AUSWD4100": "pass23",
    "AUSWD4200": "pass24",
    "AUSWD4300": "pass25",
    "AUSWD4400": "pass26",
    "AUSWD4500": "pass27",
    "AUSWD4600": "pass28"
};

app.get('/get-questions', (req, res) => {
    const safeQuestions = questionsData.map(({correct, ...rest}) => rest);
    res.json(safeQuestions);
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (allowedUsers[username] === password) res.sendStatus(200);
    else res.sendStatus(401);
});

app.post('/submit-exam', (req, res) => {
    const { username, answers, timeTaken } = req.body;
    const now = new Date();
    const subClock = now.toTimeString().split(' ')[0];

    let score = 0;
    questionsData.forEach(q => {
        if (answers[q.id] === q.correct) score++;
    });

    const result = { username, score, timeTaken, submissionClock: subClock, answers };
    if (!fs.existsSync('./student_submissions')) fs.mkdirSync('./student_submissions');
    fs.writeFileSync(`./student_submissions/${username}.json`, JSON.stringify(result, null, 2));
    
    console.log(`[${subClock}] Submission: ${username} | Duration: ${timeTaken}`);
    res.status(200).send("Success");
});

app.listen(3000, () => console.log("AUS Exam Server Live: http://localhost:3000"));